setTimeout(function(){
    location.href = "Controller/login.php";
}, 2000);